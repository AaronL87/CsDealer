using System;

namespace CsDealer
{
    public class CsDealer
    {

    }
}